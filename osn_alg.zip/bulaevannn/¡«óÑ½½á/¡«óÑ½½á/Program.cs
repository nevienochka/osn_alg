﻿using System;

class Program
{
    static void Main()
    {
        int step = 1;
        int choice;
        string ending = "";

        Console.WriteLine("добро пожаловать в новеллу 'зайчик'!");
        Console.WriteLine("вы — ученик, оказавшийся в таинственном лесу в поисках Кати.");
        Console.WriteLine();

        while (step <= 15)
        {
            switch (step)
            {
                case 1:
                    Console.WriteLine("шаг 1: вы стоите на опушке леса. куда пойдёте?");
                    Console.WriteLine("1. вправо по тропинке");
                    Console.WriteLine("2. влево по тропинке");
                    choice = GetChoice();
                    if (choice == 1) step = 2; else step = 3;
                    break;

                case 2:
                    Console.WriteLine("шаг 2: вы дошли до реки.");
                    Console.WriteLine("1. плыть через реку");
                    Console.WriteLine("2. идти вдоль берега");
                    choice = GetChoice();
                    step = (choice == 1) ? 4 : 5;
                    break;

                case 3:
                    Console.WriteLine("шаг 2: вы видите старый дом.");
                    Console.WriteLine("1. войти внутрь");
                    Console.WriteLine("2. обойти дом снаружи");
                    choice = GetChoice();
                    step = (choice == 1) ? 6 : 7;
                    break;

                case 4:
                    Console.WriteLine("шаг 3: вы плывёте через реку и находите труп.");
                    Console.WriteLine("1. закричать и уплыть");
                    Console.WriteLine("2. попытаться опознать тело");
                    choice = GetChoice();
                    step = (choice == 1) ? 8 : 9;
                    break;

                case 5:
                    Console.WriteLine("шаг 3: идёте вдоль берега и видие лису.");
                    Console.WriteLine("1. попытаться поговрить");
                    Console.WriteLine("2. пройти мимо");
                    choice = GetChoice();
                    step = (choice == 1) ? 10 : 11;
                    break;

                case 6:
                    Console.WriteLine("шаг 3: вы вошли в дом и нашли юольшую мясорубку.");
                    Console.WriteLine("1. осмотреть мясорубку");
                    Console.WriteLine("2. уйти в другую комнату");
                    choice = GetChoice();
                    step = (choice == 1) ? 12 : 13;
                    break;

                case 7:
                    Console.WriteLine("шаг 3: вы обошли дом и нашли колодец.");
                    Console.WriteLine("1. заглянуть внутрь");
                    Console.WriteLine("2. обойти колодец");
                    choice = GetChoice();
                    step = (choice == 1) ? 14 : 15;
                    break;

                case 8:
                    ending = "зловещая тайна: в мясорубке была Катя. конец.";
                    step = 16;
                    break;

                case 9:
                    ending = "дружба с лесным духом: он проводит вас через лес к скрытой тайне. конец.";
                    step = 16;
                    break;

                case 10:
                    ending = "сокровища леса: вы нашли артефакты и стали хранителем тайны. конец.";
                    step = 16;
                    break;

                case 11:
                    ending = "выживший исследователь: вы нашли безопасный путь и покинули лес. конец.";
                    step = 16;
                    break;

                case 12:
                    ending = "зловещая тайна: в ведре колодца было письмо, которое изменило вашу судьбу. конец.";
                    step = 16;
                    break;

                case 13:
                    ending = "выживший исследователь: вы решили не заглядывать в колодец, не нашли письмо и покинули лес. конец.";
                    step = 16;
                    break;

                case 14:
                    ending = "сокровища леса: дом оказался убежищем маньяка. конец."
                    step = 16;
                    break;

                case 15:
                    ending = "выживший исследователь: обойдя дом, вы нашли тропинку к выходу. конец.";
                    step = 16;
                    break;
            }
        }

        Console.WriteLine();
        Console.WriteLine(ending);
    }

    static int GetChoice()
    {
        int choice;
        while (!int.TryParse(Console.ReadLine(), out choice) || (choice != 1 && choice != 2))
        {
            Console.WriteLine("введите 1 или 2:");
        }
        return choice;
    }
}