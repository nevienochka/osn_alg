﻿using System;

class Program
{
    static void Main()
    {
        // Просим ввести сумму вклада
        Console.Write("Введите сумму вклада: ");
        double deposit = Convert.ToDouble(Console.ReadLine());

        double percent = 0; // переменная для процента
        double bonus = 15;  // фиксированный бонус

        // Определяем процент по вкладу
        if (deposit < 100)
        {
            percent = 0.05; // 5%
        }
        else if (deposit >= 100 && deposit <= 200)
        {
            percent = 0.07; // 7%
        }
        else if (deposit > 200)
        {
            percent = 0.10; // 10%
        }

        // Считаем итоговую сумму: вклад + проценты + бонус
        double result = deposit + (deposit * percent) + bonus;

        // Выводим информацию пользователю
        Console.WriteLine("Начислено " + (percent * 100) + "% и бонус " + bonus + " единиц.");
        Console.WriteLine("Итоговая сумма вклада: " + result);

        // Чтобы консоль не закрывалась сразу
        Console.ReadKey();
    }
}
