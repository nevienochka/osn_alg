﻿using System;

class Program
{
    static void Main()
    {
        // Просим ввести сумму вклада
        Console.Write("Введите сумму вклада: ");
        double deposit = Convert.ToDouble(Console.ReadLine());

        double percent = 0; // переменная для процента

        // Определяем процент по вкладу
        if (deposit < 100)
        {
            percent = 0.05; // 5%
        }
        else if (deposit >= 100 && deposit <= 200)
        {
            percent = 0.07; // 7%
        }
        else if (deposit > 200)
        {
            percent = 0.10; // 10%
        }

        // Считаем итоговую сумму
        double result = deposit + (deposit * percent);

        // Выводим результат
        Console.WriteLine("Сумма вклада с процентами: " + result);

        // Чтобы консоль не закрывалась сразу
        Console.ReadKey();
    }
}