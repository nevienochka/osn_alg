﻿using System;

class Program
{
    static void Main()
    {
        // Просим ввести два числа
        Console.Write("Введите первое число: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите второе число: ");
        double b = Convert.ToDouble(Console.ReadLine());

        // Сравниваем числа
        if (a == b)
        {
            Console.WriteLine("Два числа равны");
        }
        else if (a > b)
        {
            Console.WriteLine("Первое число больше второго");
        }
        else
        {
            Console.WriteLine("Первое число меньше второго");
        }

        // Чтобы консоль не закрывалась сразу
        Console.ReadKey();
    }
}
