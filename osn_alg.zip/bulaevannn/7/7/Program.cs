﻿using System;

class Program
{
    static void Main()
    {
        // Просим пользователя выбрать операцию
        Console.WriteLine("Введите номер операции:");
        Console.WriteLine("1. Сложение");
        Console.WriteLine("2. Вычитание");
        Console.WriteLine("3. Умножение");

        int operation = Convert.ToInt32(Console.ReadLine());

        // Просим ввести два числа
        Console.Write("Введите первое число: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите второе число: ");
        double b = Convert.ToDouble(Console.ReadLine());

        double result = 0; // переменная для хранения результата

        // Определяем действие по номеру операции
        switch (operation)
        {
            case 1:
                result = a + b;
                Console.WriteLine("Результат сложения: " + result);
                break;

            case 2:
                result = a - b;
                Console.WriteLine("Результат вычитания: " + result);
                break;

            case 3:
                result = a * b;
                Console.WriteLine("Результат умножения: " + result);
                break;

            default:
                Console.WriteLine("Операция неопределена");
                break;
        }

        // Чтобы консоль не закрывалась сразу
        Console.ReadKey();
    }
}
