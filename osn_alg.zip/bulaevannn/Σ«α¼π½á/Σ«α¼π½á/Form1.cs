﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Math;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace формула
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public double Fun(double x)
        {
            if (this.radioButton1.Checked)
                return Cos(x);

            if (this.radioButton2.Checked)
                return x * x;

            if (this.radioButton3.Checked)
                return Exp(x);

            return 0;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // Считываем значения из TextBox
            double x = Convert.ToDouble(txtX.Text);
            double y = Convert.ToDouble(txtY.Text);
            double z = Convert.ToDouble(txtZ.Text);

            // Вычисляем числитель
            double numerator = 1 + Math.Pow(Math.Sin(x + y), 2);

            // Вычисляем знаменатель
            double denominatorPart = x - (2 * y) / (1 + Math.Pow(x, 2) * Math.Pow(y, 2));
            double denominator = Math.Abs(denominatorPart);

            // Вычисляем x^|y|
            double xyPower = Math.Pow(x, Math.Abs(y));

            // Вычисляем cos^2(arctg(1/z))
            double arctgPart = Math.Atan(1 / z);
            double cosPart = Math.Pow(Math.Cos(arctgPart), 2);

            // Итоговое вычисление
            double result = (numerator / denominator) * xyPower + cosPart;

            // Выводим результат
            textResult.Text = "Результат: " + result.ToString("F4"); // F4 — округление до 4 знаков после запятой
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            {

                double x = Convert.ToDouble(textBox1.Text.Replace(',', '.'), CultureInfo.InvariantCulture);
                double y = Convert.ToDouble(textBox2.Text.Replace(',', '.'), CultureInfo.InvariantCulture);


                // ОСНОВНОЕ УСЛОВИЕ ----------------------------------------
                double xy = x * y;
                double f3 = Math.Pow(Fun(x), 3);
                richTextBox1.AppendText("x * y = " + xy + "\r\n");
                richTextBox1.AppendText("f(x)^3 = " + f3 + "\r\n");

                double c = 0;

                if (xy > 12)
                {
                    c = f3 + 1.0 / Math.Tan(y); // ctg(y) = 1/tan(y)
                    richTextBox1.AppendText("Условие: xy > 12\r\n");
                    richTextBox1.AppendText("c = f^3(x) + ctg(y)\r\n");
                }
                else if (xy < 7)
                {
                    c = Math.Sinh(f3) + y * y;
                    richTextBox1.AppendText("Условие: xy < 7\r\n");
                    richTextBox1.AppendText("c = sh(f^3(x)) + y^2\r\n");
                }
                else
                {
                    c = Math.Cos(x - f3);
                    richTextBox1.AppendText("Условие: иначе\r\n");
                    richTextBox1.AppendText("c = cos(x - f^3(x))\r\n");
                }


                if (checkBox1.Checked)
                    richTextBox1.SelectionColor = Color.Red;
                else
                    richTextBox1.SelectionColor = Color.Black;
                richTextBox1.AppendText(c.ToString());
                richTextBox1.SelectionColor = Color.Black;
            }
        }
    }
}

